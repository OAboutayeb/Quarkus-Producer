@PersistenceUnit("db2")
package org.acme.repository.db2;
import io.quarkus.hibernate.orm.PersistenceUnit;