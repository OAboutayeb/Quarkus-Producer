package org.acme.service;

import io.quarkus.hibernate.orm.PersistenceUnit;
import io.quarkus.logging.Log;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.acme.dto.StatusEnum;
import org.acme.repository.db1.Event;

import java.math.BigDecimal;
import java.util.Date;

@ApplicationScoped
public class FlowService {

    @Inject
    @PersistenceUnit("db1")
    EntityManager entityManager;

    @Inject
    @PersistenceUnit("db2")
    EntityManager entityManageEvent;


    public Uni<Event> process(Event event) {
        return switch (event.getFlow()) {
            case A -> Uni.createFrom().item(event); //TODO
            case B -> Uni.createFrom().item(event);
            case C -> Uni.createFrom().item(event);
            case D -> Uni.createFrom().item(event);
            case E -> Uni.createFrom().item(event);
            case F -> Uni.createFrom().item(event);
        };
    }

    @Transactional
    public Uni<Event> setEventToOngoing(Event event) {
        event.setStatus(StatusEnum.ONGOING);
        event.setPickUpDate(new Date());
        entityManager.persist(event);
        return Uni.createFrom().item(event);
    }

    @Transactional
    public Uni<Event> setEventToDone(Event event) {
        event.setStatus(StatusEnum.DONE);
        event.setEventDoneDate(new Date());
        entityManager.persist(event);
        return Uni.createFrom().item(event);
    }

    @Transactional
    public void saveEvent(Event event) {
        entityManager.persist(event);
    }

    public void getInfoDb2(){
        String req = "select * from indivi where INDI = 1000001611";
       BigDecimal idRsainf = (BigDecimal) entityManageEvent.createNativeQuery(req)
               .getSingleResult();
       Log.info("idRsainf db2 "+idRsainf);
    }

}