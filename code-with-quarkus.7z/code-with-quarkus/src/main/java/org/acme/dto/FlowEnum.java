package org.acme.dto;

public enum FlowEnum {
    A, B, C, D, E, F;
}
