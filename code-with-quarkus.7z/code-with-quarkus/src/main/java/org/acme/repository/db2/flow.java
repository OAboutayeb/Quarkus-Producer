package org.acme.repository.db2;

import lombok.Data;

@Data
public class flow {
    String id;
}
