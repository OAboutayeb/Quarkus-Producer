package org.acme.repository.db1;


import io.quarkus.hibernate.orm.panache.PanacheEntity;
import jakarta.persistence.*;
import lombok.Data;
import org.acme.dto.FlowEnum;
import org.acme.dto.StatusEnum;

import java.util.Date;

@Data
@Entity
public class Event extends PanacheEntity {

    @Column(nullable = false)
    private String author;
    @Column(nullable = false)
    private String tenant;
    @Column(nullable = false)
    private String beneficiaire;
    private String idFunctional;
    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private FlowEnum flow;
    private Date creationDate;
    private Date pickUpDate;
    private Date eventDoneDate;
    @Enumerated(EnumType.STRING)
    private StatusEnum status;
    @Lob
    private String message;
}
