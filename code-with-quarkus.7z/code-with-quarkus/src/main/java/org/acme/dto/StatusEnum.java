package org.acme.dto;

public enum StatusEnum {
    CREATED, ONGOING, DONE, FUNC_ERROR, TECH_ERROR;
}
