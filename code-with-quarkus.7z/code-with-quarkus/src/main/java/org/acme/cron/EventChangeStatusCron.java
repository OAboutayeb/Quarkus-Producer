package org.acme.cron;


import io.quarkus.logging.Log;
import io.quarkus.scheduler.Scheduled;
import io.quarkus.scheduler.Scheduled.ConcurrentExecution;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import org.acme.dto.StatusEnum;
import org.acme.repository.db1.Event;
import org.acme.repository.EventRepository;
import org.acme.service.FlowService;

@ApplicationScoped
public class EventChangeStatusCron {
    @Inject
    private FlowService flowService;

    @Inject
    private EventRepository eventRepository;


  
    @Transactional
    @Scheduled(every = "10s")
    Uni<Void> handleEvents() {
        Log.info("Start handle Events - non blocking code");
        // Async (non-blocking) code that iterate over events and do the "cronJobImpl()" and return a void uni
        return Multi.createBy()
                // iterate over events
                .repeating().uni(() ->  eventRepository.getFirstEventByStatus(StatusEnum.CREATED)
                        .chain(event -> {
                            Log.debug("handleEvents value " + event);
                            if (event == null) {
                                event = new Event();
                                event.setStatus(StatusEnum.TECH_ERROR);
                                return Uni.createFrom().item(event);
                            }
                            Event finalEvent = event;
                            return  flowService.setEventToOngoing(event)
                                    .chain(eventOngoing -> flowService.process(eventOngoing))
                                    .chain(eventTodone -> flowService.setEventToDone(finalEvent))
                                    .onFailure().recoverWithItem(failure -> handleFailure(failure, finalEvent));

                        }))
                // until an event that does not exists
                .until(event -> !event.getStatus().equals(StatusEnum.CREATED))
                // map returns and return a void uni
                .map(result -> result).collect().asList().replaceWithVoid();
    }


    private Event handleFailure (Throwable failure, Event event){

        event.setStatus(StatusEnum.FUNC_ERROR);
        event.setMessage(failure.getMessage());
        flowService.saveEvent(event);
        return event;
    }


}