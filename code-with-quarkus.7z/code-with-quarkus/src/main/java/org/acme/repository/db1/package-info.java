@PersistenceUnit("db1")
package org.acme.repository.db1;
import io.quarkus.hibernate.orm.PersistenceUnit;