package org.acme.repository;


import io.quarkus.hibernate.orm.PersistenceUnit;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import io.quarkus.panache.common.Page;
import io.quarkus.panache.common.Sort;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.acme.dto.StatusEnum;
import org.acme.repository.db1.Event;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@ApplicationScoped
public class EventRepository implements PanacheRepository<Event> {
    private static final String DESC_SORT = "DESC";
    private final ExecutorService executorService = Executors.newFixedThreadPool(5);

    @Inject
    @PersistenceUnit("db1")
    EntityManager entityManager;

    public Uni<List<Event>> getEventsByStatus(int page, int limit, String order, Map<String, Object> statusMap) {
        return Uni.createFrom().item(find("status in (:status)",
        		order.equals(DESC_SORT) ? Sort.descending("creationDate") : Sort.ascending("creationDate"), statusMap)
        		.page(Page.of(page, limit)).list());
    }

    public Uni<Event> getFirstEventByStatus(StatusEnum status) {
        String jpql = "SELECT ev FROM Event ev WHERE ev.status = :status";
        return Uni.createFrom().item(() ->
                entityManager.createQuery(jpql, Event.class)
                       .setParameter("status", status)
                       .getResultList().stream().findFirst().isPresent()?   entityManager.createQuery(jpql, Event.class)
                        .setParameter("status", status)
                        .getResultList().stream().findFirst().get():null
                ).runSubscriptionOn(executorService);

    }

    @Transactional
    public Uni<Event> persistEvent(Event event) {
        entityManager.persist(event);
    	return Uni.createFrom().item(event);
    }
}
